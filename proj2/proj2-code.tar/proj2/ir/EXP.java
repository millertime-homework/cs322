package ir;

public abstract class EXP extends IR {
  public abstract EXP accept(IrVI v);
}


