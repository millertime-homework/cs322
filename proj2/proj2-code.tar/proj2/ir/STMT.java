package ir;

public abstract class STMT extends IR {
  public abstract STMT accept(IrVI v);
}
