// for MINI v1.6. (Jingke Li)
//
package symbol;

public class SymbolException extends Exception {
  public String message;

  public SymbolException(String msg) { message = msg; }
}
