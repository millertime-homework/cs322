// test if statements
class test {
  public static void main(String[] a) {
    int i=0;
    if (2>1) if (1>0) i=1; else i=2;
    System.out.println(i);
  }
}

