// test floating point
// (should print 11.2)
class test {
  public static void main(String[] a) {
    float x;
    x = 1.2F + 2.5f * 4;
    System.out.println(x);
  }
}
